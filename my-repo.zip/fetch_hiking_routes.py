import streamlit as st
import requests
import json
import folium
import polyline
import random
from streamlit_folium import folium_static
from folium.plugins import MarkerCluster
import pandas as pd
from PIL import Image
import io
import base64
import os
from datetime import datetime
import numpy as np
from streamlit_card import card
from geopy.geocoders import Nominatim
import numpy as np
from sklearn.neighbors import NearestNeighbors
import pickle
from get_personalized_recommendations import get_personalized_recommendations 
from key import OPENROUTE_API_KEY
# Function to fetch hiking trails
def fetch_hiking_routes(latitude, longitude, radius=10000):
    # Original code to fetch/generate hiking routes
    sample_routes = []
    
    # Create 5 sample routes
    for i in range(5):
        # Generate start point with slight offset from provided coordinates
        start_lat = latitude + (random.random() - 0.5) * 0.05
        start_lon = longitude + (random.random() - 0.5) * 0.05
        
        # Generate end point
        end_lat = start_lat + (random.random() - 0.5) * 0.02
        end_lon = start_lon + (random.random() - 0.5) * 0.02
        
        # Calculate the coordinates for the route (simplified as a straight line for demo)
        num_points = 10
        route_coordinates = []
        for j in range(num_points):
            point_lat = start_lat + (end_lat - start_lat) * j / (num_points - 1)
            point_lon = start_lon + (end_lon - start_lon) * j / (num_points - 1)
            route_coordinates.append([point_lat, point_lon])
        
        # Calculate estimated distance and time
        distance_km = round(random.uniform(2, 15), 1)  # Random distance between 2 and 15 km
        estimated_time = round(distance_km / 4 * 60)  # Assuming 4 km/h average speed
        
        # Create route object
        route = {
            "id": f"hiking_{i}",
            "name": f"Hiking Trail {i+1}",
            "coordinates": route_coordinates,
            "distance_km": distance_km,
            "estimated_time_min": estimated_time,
            "difficulty": random.choice(["Easy", "Moderate", "Hard"]),
            "elevation_gain": round(random.uniform(50, 500)),  # Random elevation gain in meters
            "type": "Hiking",
            "image_url": None  # We'll generate this from the map
        }
        
        sample_routes.append(route)
    
    # Apply personalized recommendations if model exists
    if st.session_state.recommendation_model:
        sample_routes = get_personalized_recommendations(sample_routes)
    
    return sample_routes

# Function to fetch cycling routes
def fetch_cycling_routes(latitude, longitude, radius=10000):
    # Similar to hiking, but with longer routes and faster expected speeds
    sample_routes = []
    
    for i in range(5):
        start_lat = latitude + (random.random() - 0.5) * 0.05
        start_lon = longitude + (random.random() - 0.5) * 0.05
        
        end_lat = start_lat + (random.random() - 0.5) * 0.04
        end_lon = start_lon + (random.random() - 0.5) * 0.04
        
        num_points = 15
        route_coordinates = []
        for j in range(num_points):
            point_lat = start_lat + (end_lat - start_lat) * j / (num_points - 1)
            point_lon = start_lon + (end_lon - start_lon) * j / (num_points - 1)
            route_coordinates.append([point_lat, point_lon])
        
        distance_km = round(random.uniform(5, 30), 1)  # Cycling routes are typically longer
        estimated_time = round(distance_km / 15 * 60)  # Assuming 15 km/h average speed
        
        route = {
            "id": f"cycling_{i}",
            "name": f"Cycling Route {i+1}",
            "coordinates": route_coordinates,
            "distance_km": distance_km,
            "estimated_time_min": estimated_time,
            "difficulty": random.choice(["Easy", "Moderate", "Hard"]),
            "elevation_gain": round(random.uniform(100, 800)),
            "type": "Cycling",
            "image_url": None
        }
        
        sample_routes.append(route)
    
    return sample_routes
