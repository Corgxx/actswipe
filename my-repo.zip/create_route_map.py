import streamlit as st
import requests
import json
import folium
import polyline
import random
from streamlit_folium import folium_static
from folium.plugins import MarkerCluster
import pandas as pd
from PIL import Image
import io
import base64
import os
from datetime import datetime
import numpy as np
from streamlit_card import card
from geopy.geocoders import Nominatim
import numpy as np
from sklearn.neighbors import NearestNeighbors
import pickle

# Function to create a map for a route
def create_route_map(coordinates, start_icon='play', end_icon='stop'):
    # Create map centered at the middle point of the route
    mid_point = coordinates[len(coordinates)//2]
    m = folium.Map(location=mid_point, zoom_start=13)
    
    # Add the route line
    folium.PolyLine(
        coordinates,
        color='blue',
        weight=5,
        opacity=0.7
    ).add_to(m)
    
    # Add markers for start and end points
    start_point = coordinates[0]
    end_point = coordinates[-1]
    
    folium.Marker(
        location=start_point,
        icon=folium.Icon(color='green', icon=start_icon),
        popup='Start'
    ).add_to(m)
    
    folium.Marker(
        location=end_point,
        icon=folium.Icon(color='red', icon=end_icon),
        popup='End'
    ).add_to(m)
    
    return m