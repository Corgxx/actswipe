import streamlit as st
import requests
import json
import folium
import polyline
import random
from streamlit_folium import folium_static
from folium.plugins import MarkerCluster
import pandas as pd
from PIL import Image
import io
import base64
import os
from datetime import datetime
import numpy as np
from streamlit_card import card
from geopy.geocoders import Nominatim
import numpy as np
from sklearn.neighbors import NearestNeighbors
import pickle

# Function to fetch cycling routes
def fetch_cycling_routes(latitude, longitude, radius=10000):
    # Similar to hiking, but with longer routes and faster expected speeds
    sample_routes = []
    
    for i in range(5):
        start_lat = latitude + (random.random() - 0.5) * 0.05
        start_lon = longitude + (random.random() - 0.5) * 0.05
        
        end_lat = start_lat + (random.random() - 0.5) * 0.04
        end_lon = start_lon + (random.random() - 0.5) * 0.04
        
        num_points = 15
        route_coordinates = []
        for j in range(num_points):
            point_lat = start_lat + (end_lat - start_lat) * j / (num_points - 1)
            point_lon = start_lon + (end_lon - start_lon) * j / (num_points - 1)
            route_coordinates.append([point_lat, point_lon])
        
        distance_km = round(random.uniform(5, 30), 1)  # Cycling routes are typically longer
        estimated_time = round(distance_km / 15 * 60)  # Assuming 15 km/h average speed
        
        route = {
            "id": f"cycling_{i}",
            "name": f"Cycling Route {i+1}",
            "coordinates": route_coordinates,
            "distance_km": distance_km,
            "estimated_time_min": estimated_time,
            "difficulty": random.choice(["Easy", "Moderate", "Hard"]),
            "elevation_gain": round(random.uniform(100, 800)),
            "type": "Cycling",
            "image_url": None
        }
        
        sample_routes.append(route)
    
    return sample_routes
