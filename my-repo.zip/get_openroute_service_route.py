import streamlit as st
import requests
import json
import folium
import polyline
import random
from streamlit_folium import folium_static
from folium.plugins import MarkerCluster
import pandas as pd
from PIL import Image
import io
import base64
import os
from datetime import datetime
import numpy as np
from streamlit_card import card
from geopy.geocoders import Nominatim
import numpy as np
from sklearn.neighbors import NearestNeighbors
import pickle
from key import OPENROUTE_API_KEY
# Function to get actual routes from OpenRouteService API
def get_openroute_service_route(start_coords, end_coords, profile='foot-hiking'):
    """
    Get a route from OpenRouteService API
    profiles: foot-hiking, cycling-regular, cycling-mountain, cycling-road
    """
    base_url = "https://api.openrouteservice.org/v2/directions/"
    
    # Reorder coordinates for the API [longitude, latitude]
    start = f"{start_coords[1]},{start_coords[0]}"
    end = f"{end_coords[1]},{end_coords[0]}"
    
    url = f"{base_url}{profile}"
    headers = {
        'Authorization': OPENROUTE_API_KEY,
        'Content-Type': 'application/json'
    }
    
    body = {
        "coordinates": [[float(start_coords[1]), float(start_coords[0])], 
                        [float(end_coords[1]), float(end_coords[0])]],
        "elevation": "true"
    }
    
    try:
        response = requests.post(url, json=body, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            if 'routes' in data and len(data['routes']) > 0:
                route = data['routes'][0]
                geometry = route['geometry']
                # Convert encoded polyline to coordinates
                coords = polyline.decode(geometry, geojson=True)
                
                # Extract distance and duration
                distance_km = route['summary']['distance'] / 1000
                duration_min = route['summary']['duration'] / 60
                
                # Extract elevation data if available
                elevation_gain = 0
                if 'ascent' in route['summary']:
                    elevation_gain = route['summary']['ascent']
                
                return {
                    'coordinates': coords,
                    'distance_km': distance_km,
                    'duration_min': duration_min,
                    'elevation_gain': elevation_gain
                }
            else:
                st.error("No routes found in the response")
                return None
        else:
            st.error(f"Error from OpenRouteService API: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        st.error(f"Exception when calling OpenRouteService API: {e}")
        return None
